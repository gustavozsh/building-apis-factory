<!-- omit from toc -->
# Google Analytics 4 Module

This Python module allows you to extract data from Google Analytics 4 (GA4). The data is returned as a Pandas DataFrame, making it easy to work with in a variety of data processing and analysis workflows.

<!-- omit from toc -->
## Table of contents
- [Usage \& Examples](#usage--examples)
  - [Initialization](#initialization)
  - [Examples](#examples)
  - [Requesting metadata](#requesting-metadata)
- [Methods](#methods)
  - [request\_report -\> pd.DataFrame](#request_report---pddataframe)
  - [get\_metadata -\> dict](#get_metadata---dict)


## Usage & Examples
### Initialization
To use the GoogleAnalytics4 class, you need to provide a Google Credentials object. You can generate these credentials by following the Google Cloud documentation.

Here's an example using an OAuth token:
```
from google.oauth2.credentials import Credentials
from cadastra_core import GoogleAnalytics4
from cadastra_core import SecretManager

# Retrieve the Service Account JSON
secret_manager = SecretManager()
secret_id = "your-secret-id"
project_id = "your-project-id"

secret_value = secret_manager.access_secret_version(
    secret_id=secret_id,
    project_id=project_id
)

# Initialize credentials
credentials_dict = json.loads(secret_value)
credentials = Credentials.from_authorized_user_info(credentials_dict)

# Instantiate the GoogleAnalytics4 class
ga4 = GoogleAnalytics4(credentials)
```

Here's an example using a Service Account retrieved using the Secret Manager module:
```
from google.oauth2.service_account import Credentials
from cadastra_core import GoogleAnalytics4
from cadastra_core import SecretManager

# Retrieve the Service Account JSON
secret_manager = SecretManager()
secret_id = "your-secret-id"
project_id = "your-project-id"

secret_value = secret_manager.access_secret_version(
    secret_id=secret_id,
    project_id=project_id
)

# Load the JSON and create the Credentials object
service_account_json = json.loads(secret_value)
credentials_service_account_json = Credentials.from_service_account_info(service_account_json)

# Instantiate the GoogleAnalytics4 class
ga4 = GoogleAnalytics4(credentials_service_account_json)
```
### Examples
#### Requesting a Report
You can request a report by calling the `request_report` method. This method retrieves the desired data from GA4 and returns it as a Pandas DataFrame.

```
# Define parameters
property_id = 'YOUR_GA4_PROPERTY_ID'
start_date = '2023-01-01'
end_date = '2023-01-31'
dimensions = ['date', 'eventName']
metrics = ['activeUsers']

# Request the report
df = ga4.request_report(
    property_id=property_id,
    start_date=start_date,
    end_date=end_date,
    dimensions=dimensions,
    metrics=metrics
)

# View the resulting DataFrame
print(df)
```

#### Requesting a Report with Filters
```
# Define parameters
property_id = 'YOUR_GA4_PROPERTY_ID'
start_date = '2023-01-01'
end_date = '2023-01-31'
dimensions = ['date', 'eventName']
metrics = ['activeUsers']
dimension_filters = [
    {
        "field_name": "eventName",
        "string_filter": {
            "match_type": "CONTAINS",
            "value": "purchase",
            "case_sensitive": False,
        },
    },
    {
        "field_name": "eventName",
        "string_filter": {
            "match_type": "CONTAINS",
            "value": "purchases",
            "case_sensitive": False,
        },
    },
]
metric_filters = [
    {
        "field_name": "activeUser",
        "numeric_filter": {"operation": "GREATER_THAN", "value": {"int64_value": "10"}},
    } 
]
dimension_group_type = "OR"
metric_group_type = "OR"

# Request the report
df = ga4.request_report(
    property_id=property_id,
    start_date=start_date,
    end_date=end_date,
    dimensions=dimensions,
    metrics=metrics
    dimnesion_filter=dimension_filters,
    metric_filter=metric_filters,
    dimension_group_type=dimension_group_type,
    metric_group_type=metric_group_type,
)

# View the resulting DataFrame
print(df)
```
To better understand the possibilities of the filters check this [documentation](https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1alpha/FilterExpression).

### Requesting metadata
You can request metadata from GA4 by calling the `get_metadata` method. This method retrieves the desired data from GA4 and returns it as a Dictionary.

```
# pprint is a Python module that formats and displays data structures, such as dictionaries, making them easier to understand.
from pprint import pprint
# Define parameters
property_id = 'YOUR_GA4_PROPERTY_ID'

# Request the metadata
dict = ga4.get_metadata(property_id=property_id)

# View the resulting Dictionary
pprint(dict)
```


## Methods
### request_report -> pd.DataFrame
| Parameter name | Type | Required | Description | Default value |
|-|-|-|-|-|
property_id | int / str | :white_check_mark: | The GA4 Property ID |
start_date | str | :white_check_mark: | The start date for the report in YYYY-MM-DD format |
end_date | str | :white_check_mark: | The end date for the report in YYYY-MM-DD format |
dimensions | list[str] | :white_check_mark: | A list of dimension names according to the API (e.g., ['date', 'eventName']) |
metrics | list[str] | :white_check_mark: | A list of metric names according to the API (e.g., ['activeUsers']) |
dimension_filter | list[Dict[str, Union[str, Dict]]] | | A list of dimension filters. | `[]` |
metric_filter | list[Dict[str, Union[str, Dict]]] | | A list of metric filters. | `[]` |
row_limit | int | | The limit on the number of rows returned | `250000`
dimension_group_type | str | | Group type for dimension filters. Must be one of "AND", "OR", or "NOT". | `"AND"` |
metric_group_type | str | | Group type for metric filters. Must be one of "AND", "OR", or "NOT". | `"AND"` |

**Returns: A Pandas Dataframe with the requested data**

### get_metadata -> dict

| Parameter name | Type | Required | Description |
|---|---|---|---|
| `property_id` | int / str | :white_check_mark: | GA4 Property ID |

**Returns:** dict - A dictionary containing two arrays: one for dimensions and another for metrics available. Details in the table below. 



| Level     | Key                    | Data Type          | Description                                                                 |
|-----------|------------------------|--------------------|-----------------------------------------------------------------------------|
| Root      | dimensions              | list               | A list of dictionaries, each representing a dimension.                      |
| Root      | metrics                 | list               | A list of dictionaries, each representing a metric.                         |
| Dimension | api_name                | string             | The API name of the dimension.                                              |
| Dimension | ui_name                 | string             | The human-readable name of the dimension as seen in the UI.                 |
| Dimension | description             | string             | A brief description of the dimension.                                       |
| Dimension | category                | string             | The category the dimension belongs to.                                      |
| Dimension | custom_definition       | boolean            | Indicates if the dimension is custom-defined.                               |
| Dimension | deprecated_api_names    | list of strings    | A list of deprecated API names.                                             |
| Metric    | api_name                | string             | The API name of the metric.                                                 |
| Metric    | ui_name                 | string             | The human-readable name of the metric as seen in the UI.                    |
| Metric    | description             | string             | A brief description of the metric.                                          |
| Metric    | category                | string             | The category the metric belongs to.                                         |
| Metric    | type                    | string             | The data type of the metric.                                                |
| Metric    | expression              | string             | The expression used for calculated metrics.                                 |
| Metric    | custom_definition       | boolean            | Indicates if the metric is custom-defined.                                  |
| Metric    | blocked_reasons         | list of strings    | Reasons why the metric might be blocked.                                    |

