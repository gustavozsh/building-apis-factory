from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.oauth2.service_account import Credentials as SA_Credentials
from google.oauth2.credentials import Credentials as OAuth_Credentials
from typing import Union
from datetime import datetime, timedelta
from google.analytics.data_v1beta.types import GetMetadataRequest

from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter,
    FilterExpressionList,
    NumericValue,
)
from loguru import logger
import pandas as pd


class GoogleAnalytics4:
    def __init__(self, credentials: SA_Credentials | OAuth_Credentials):
        """Instantiates a GA4 client

        Args:
            credentials (SA_Credentials | OAuth_Credentials): google.oauth2.service_account.Credentials or google.oauth2.credentials.Credentials object
        """
        self.analytics_client: BetaAnalyticsDataClient = BetaAnalyticsDataClient(
            credentials=credentials
        )

    def __to_dataframe(self, response: dict) -> pd.DataFrame:
        dimension_headers = [header.name for header in response.dimension_headers]
        metric_headers = [header.name for header in response.metric_headers]

        dimensions = [
            [row.dimension_values[i].value for row in response.rows]
            for i in range(len(dimension_headers))
        ]

        metrics = [
            [row.metric_values[i].value for row in response.rows]
            for i in range(len(metric_headers))
        ]

        headers = dimension_headers + metric_headers
        data = dimensions + metrics

        report_dataframe = pd.DataFrame(data).transpose()
        report_dataframe.columns = headers

        return report_dataframe

    def __build_filter_expression(
        self, filters: list[dict[str, Union[str, dict]]], group_type: str
    ) -> FilterExpression:
        """
        Builds a FilterExpression for Google Analytics 4 based on the provided filters and group type.

        Args:
            filters (list[dict[str, Union[str, dict]]]): A list of dictionaries where each dictionary represents a filter.
                Each filter dictionary must contain a "field_name" key and one of the following keys:
                - "string_filter": A dictionary with keys "match_type", "value", and "case_sensitive".
                - "in_list_filter": A dictionary with keys "values" and "case_sensitive".
                - "numeric_filter": A dictionary with keys "operation" and "value" (which contains either "int64_value" or "double_value").
                - "between_filter": A dictionary with keys "from_value" and "to_value" (each containing either "int64_value" or "double_value").
                - "null_filter": A boolean indicating if the filter is for null values.
            group_type (str): The type of group for the filter expressions. Must be one of "AND", "OR", or "NOT".

        Returns:
            FilterExpression: The constructed FilterExpression object.

        Raises:
            ValueError: If an invalid filter type is provided or if the group_type is invalid.
        """
        expressions = []

        for filter in filters:
            if "string_filter" in filter:
                filter_obj = Filter(
                    field_name=filter["field_name"],
                    string_filter=Filter.StringFilter(
                        match_type=filter["string_filter"].get("match_type", "EXACT"),
                        value=filter["string_filter"]["value"],
                        case_sensitive=filter["string_filter"].get(
                            "case_sensitive", False
                        ),
                    ),
                )
            elif "in_list_filter" in filter:
                filter_obj = Filter(
                    field_name=filter["field_name"],
                    in_list_filter=Filter.InListFilter(
                        values=filter["in_list_filter"]["values"],
                        case_sensitive=filter["in_list_filter"].get(
                            "case_sensitive", False
                        ),
                    ),
                )
            elif "numeric_filter" in filter:
                filter_obj = Filter(
                    field_name=filter["field_name"],
                    numeric_filter=Filter.NumericFilter(
                        operation=filter["numeric_filter"]["operation"],
                        value=NumericValue(
                            int64_value=filter["numeric_filter"]["value"].get(
                                "int64_value"
                            ),
                            double_value=filter["numeric_filter"]["value"].get(
                                "double_value"
                            ),
                        ),
                    ),
                )
            elif "between_filter" in filter:
                filter_obj = Filter(
                    field_name=filter["field_name"],
                    between_filter=Filter.BetweenFilter(
                        from_value=NumericValue(
                            int64_value=filter["between_filter"]["from_value"].get(
                                "int64_value"
                            ),
                            double_value=filter["between_filter"]["from_value"].get(
                                "double_value"
                            ),
                        ),
                        to_value=NumericValue(
                            int64_value=filter["between_filter"]["to_value"].get(
                                "int64_value"
                            ),
                            double_value=filter["between_filter"]["to_value"].get(
                                "double_value"
                            ),
                        ),
                    ),
                )
            elif "null_filter" in filter:
                filter_obj = Filter(
                    field_name=filter["field_name"], null_filter=filter["null_filter"]
                )
            else:
                raise ValueError("Invalid filter type provided.")

            expressions.append(FilterExpression(filter=filter_obj))

        if group_type.upper() == "AND":
            return FilterExpression(
                and_group=FilterExpressionList(expressions=expressions)
            )
        elif group_type.upper() == "OR":
            return FilterExpression(
                or_group=FilterExpressionList(expressions=expressions)
            )
        elif group_type.upper() == "NOT":
            if len(expressions) != 1:
                raise ValueError(
                    "NOT group must contain exactly one filter expression."
                )
            return FilterExpression(not_expression=expressions[0])
        else:
            raise ValueError("Invalid group_type. Must be 'AND', 'OR', or 'NOT'.")

    def request_report(
        self,
        property_id: int | str,
        start_date: str,
        end_date: str,
        dimensions: list[str],
        metrics: list[str],
        dimension_filter: list = [],
        metric_filter: list = [],
        row_limit=250000,
        dimension_group_type="AND",
        metric_group_type="AND",
    ) -> pd.DataFrame:
        """Function to extract the desired report from GA4 and return the dataframe with the data.

        Args:
            property_id (int | str): GA4 Property ID
            start_date (str): Start date in format 'YYYY-MM-DD'
            end_date (str): End date in format 'YYYY-MM-DD'
            dimensions (list[str]): Array with dimension names according to the API like ['date', 'eventName']
            metrics (list[str]): Array with metric names according to the API like ['date', 'eventName']
            dimension_filters (List[Dict[str, Union[str, Dict]]], optional): List of dimension filters. Defaults to [].
            metric_filters (List[Dict[str, Union[str, Dict]]], optional): List of metric filters. Defaults to [].
            row_limit (int, optional): Returned rows limit. Defaults to 250000.
            dimension_group_type (str, optional): Group type for dimension filters. Defaults to "AND".
            metric_group_type (str, optional): Group type for metric filters. Defaults to "AND".

        Returns:
            pd.DataFrame: the dataframe with the data
        """
        self.property_id = property_id
        self.start_date = start_date
        self.end_date = end_date
        self.dimensions = dimensions
        self.metrics = metrics
        self.dimension_filter = dimension_filter
        self.metric_filter = metric_filter
        self.row_limit = row_limit
        self.full_report_df = pd.DataFrame()

        logger.info(
            f"Creating GA4 request with params: Property ID: {self.property_id} | Date Range: {self.start_date}_{self.end_date} | Dimensions: {self.dimensions} | Metrics: {self.metrics} | Row limit: {self.row_limit}"
        )
        dimension_filter_expression = {}
        metric_filter_expression = {}

        if dimension_filter not in [{}, None, "", []]:
            dimension_filter_expression = self.__build_filter_expression(
                dimension_filter, dimension_group_type
            )

        if metric_filter not in [{}, None, "", []]:
            metric_filter_expression = self.__build_filter_expression(
                metric_filter, metric_group_type
            )

        start_tmp = datetime.strptime(self.start_date, "%Y-%m-%d")
        end_tmp = datetime.strptime(self.end_date, "%Y-%m-%d")

        while start_tmp <= end_tmp:
            date_ref = start_tmp.strftime("%Y-%m-%d")
            logger.info(f"Extracting {date_ref}")

            request_params = {
                "property": f"properties/{self.property_id}",
                "date_ranges": [DateRange(start_date=date_ref, end_date=date_ref)],
                "dimensions": [
                    Dimension(name=dimension) for dimension in self.dimensions
                ],
                "metrics": [Metric(name=metric) for metric in self.metrics],
                "limit": self.row_limit,
            }

            if dimension_filter_expression:
                request_params["dimension_filter"] = dimension_filter_expression

            if metric_filter_expression:
                request_params["metric_filter"] = metric_filter_expression

            request = RunReportRequest(**request_params)

            report_result = self.analytics_client.run_report(request)

            df_tmp = self.__to_dataframe(report_result)

            self.full_report_df = pd.concat(
                [self.full_report_df, df_tmp], ignore_index=True
            )
            start_tmp = start_tmp + timedelta(days=1)

        return self.full_report_df

    def get_metadata(self, property_id: int | str) -> dict:
        """Function to retrieve metadata from a GA4 property and return a dictionary containing accessible dimensions and metrics along with their attributes.
        The dimensions and metrics are detailed with their respective API names, UI names, descriptions, categories, and other relevant metadata.

        Args:
            property_id (int | str): GA4 Property ID

        Returns:
            dict: dictionary containing two arrays: one for dimensions and another for metrics available.
                dimensions: A list of dictionaries, where each dictionary represents a dimension and contains the following keys:
                -api_name: The API name of the dimension (e.g., sessionSource).
                -ui_name: The human-readable name of the dimension as seen in the UI (e.g., Session Source).
                -description: A brief description of the dimension, explaining its purpose.
                -category: The category the dimension belongs to, such as "User" or "Traffic".
                -custom_definition: A boolean value indicating whether the dimension is a custom (user-defined) or a standard definition.
                -deprecated_api_names: A list of deprecated or older API names for the dimension, if any.

                metrics: A list of dictionaries, where each dictionary represents a metric and contains the following keys:
                -api_name: The API name of the metric (e.g., activeUsers).
                -ui_name: The human-readable name of the metric as seen in the UI (e.g., Active Users).
                -description: A brief description of the metric, explaining its purpose.
                -category: The category the metric belongs to, such as "User" or "Engagement".
                -type: The data type of the metric (e.g., TYPE_INTEGER, TYPE_FLOAT).
                -expression: If the metric is calculated, this key contains the expression used for the calculation. Otherwise, it is null.
                -custom_definition: A boolean value indicating whether the metric is a custom (user-defined) or a standard definition.
                -blocked_reasons: A list of reasons why the metric might be blocked or unavailable, if applicable.

        """
        # request to retrieve metadata GA4
        request = GetMetadataRequest(name=f"properties/{property_id}/metadata")
        metadata = self.analytics_client.get_metadata(request=request)

        dimensions = [
            {
                "api_name": dim.api_name,
                "ui_name": dim.ui_name,
                "description": dim.description,
                "category": dim.category,
                "custom_definition": dim.custom_definition,
                "deprecated_api_names": dim.deprecated_api_names,
            }
            for dim in metadata.dimensions
        ]

        metrics = [
            {
                "api_name": met.api_name,
                "ui_name": met.ui_name,
                "description": met.description,
                "category": met.category,
                "type": met.type_,  # `type_` to avoid conflict with reserved word `type`
                "expression": met.expression,
                "custom_definition": met.custom_definition,
                "blocked_reasons": met.blocked_reasons,
            }
            for met in metadata.metrics
        ]

        # return a dictionary with
        logger.success(f"success returning metadata for property {property_id}")
        return {"dimensions": dimensions, "metrics": metrics}