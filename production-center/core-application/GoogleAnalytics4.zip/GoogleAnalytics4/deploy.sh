#!/bin/bash

# Script para deploy no Google Cloud Run
# Uso: ./deploy.sh PROJECT_ID REGION

if [ $# -lt 2 ]; then
    echo "Uso: ./deploy.sh <PROJECT_ID> <REGION>"
    echo "Exemplo: ./deploy.sh my-project-123 us-central1"
    exit 1
fi

PROJECT_ID=$1
REGION=$2
SERVICE_NAME="ga4-api"
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

echo "=== Iniciando deploy para Google Cloud Run ==="
echo "Projeto: ${PROJECT_ID}"
echo "Região: ${REGION}"
echo "Serviço: ${SERVICE_NAME}"
echo ""

# 1. Configurar projeto
echo "1. Configurando projeto GCP..."
gcloud config set project ${PROJECT_ID}

# 2. Habilitar APIs necessárias
echo "2. Habilitando APIs necessárias..."
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
gcloud services enable bigquery.googleapis.com

# 3. Criar dataset BigQuery (se não existir)
echo "3. Verificando dataset BigQuery..."
if ! bq ls -d | grep -q ga4_data; then
    echo "   Criando dataset ga4_data..."
    bq mk --dataset \
        --description="GA4 Analytics Data" \
        ga4_data
else
    echo "   Dataset ga4_data já existe"
fi

# 4. Build da imagem Docker
echo "4. Fazendo build da imagem Docker..."
gcloud builds submit \
    --tag ${IMAGE_NAME}:latest \
    --project=${PROJECT_ID}

if [ $? -ne 0 ]; then
    echo "Erro no build. Abortando."
    exit 1
fi

# 5. Solicitar credenciais
echo ""
echo "5. Configurando variáveis de ambiente..."
echo ""
echo "IMPORTANTE: Você precisa fornecer:"
echo "  - Arquivo JSON com as credenciais da Service Account"
echo ""
read -p "Caminho do arquivo de credenciais (key.json): " CREDS_FILE

if [ ! -f "$CREDS_FILE" ]; then
    echo "Arquivo não encontrado: $CREDS_FILE"
    exit 1
fi

# Converter credenciais para string
CREDS_JSON=$(cat "$CREDS_FILE" | jq -c .)

# 6. Deploy no Cloud Run
echo ""
echo "6. Fazendo deploy no Cloud Run..."
gcloud run deploy ${SERVICE_NAME} \
    --image ${IMAGE_NAME}:latest \
    --platform managed \
    --region ${REGION} \
    --allow-unauthenticated \
    --memory 512Mi \
    --cpu 1 \
    --timeout 300 \
    --max-instances 100 \
    --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID},BIGQUERY_DATASET_ID=ga4_data,BIGQUERY_TABLE_ID=analytics_report,GOOGLE_CREDENTIALS=${CREDS_JSON}" \
    --project=${PROJECT_ID}

if [ $? -eq 0 ]; then
    echo ""
    echo "=== Deploy concluído com sucesso! ==="
    echo ""
    
    # Obter URL do serviço
    SERVICE_URL=$(gcloud run services describe ${SERVICE_NAME} \
        --platform managed \
        --region ${REGION} \
        --project ${PROJECT_ID} \
        --format='value(status.url)')
    
    echo "URL do serviço: ${SERVICE_URL}"
    echo ""
    echo "Endpoints disponíveis:"
    echo "  - Health: ${SERVICE_URL}/health"
    echo "  - Relatório: ${SERVICE_URL}/api/v1/report (POST)"
    echo "  - Metadados: ${SERVICE_URL}/api/v1/metadata (POST)"
    echo "  - Schema: ${SERVICE_URL}/api/v1/bigquery/schema (GET)"
    echo "  - Query: ${SERVICE_URL}/api/v1/bigquery/query (POST)"
    echo ""
    echo "Para ver logs:"
    echo "  gcloud run logs read ${SERVICE_NAME} --region=${REGION} --project=${PROJECT_ID}"
else
    echo "Erro no deploy. Verifique os logs acima."
    exit 1
fi
