"""
EXEMPLOS PRÁTICOS - GA4 to BigQuery API
Copie e adapte esses exemplos para suas necessidades
"""

# ============================================================================
# EXEMPLO 1: Requisição Básica com cURL
# ============================================================================

"""
# Health check (nenhuma autenticação necessária)
curl http://localhost:8080/health

# Resultado esperado:
# {"status": "healthy"}
"""

# ============================================================================
# EXEMPLO 2: Buscar Relatório GA4 com cURL
# ============================================================================

"""
curl -X POST http://localhost:8080/api/v1/report \
  -H "Content-Type: application/json" \
  -d '{
    "property_id": "123456789",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "dimensions": ["date", "eventName"],
    "metrics": ["activeUsers", "eventCount"]
  }'

# Resultado esperado:
# {
#   "status": "success",
#   "rows_processed": 1250,
#   "property_id": "123456789",
#   "bigquery_table": "my-project.ga4_data.analytics_report"
# }
"""

# ============================================================================
# EXEMPLO 3: Python - Requisição Simples
# ============================================================================

import requests
import json

API_URL = "http://localhost:8080"  # Local
# API_URL = "https://ga4-api-xxxxx.run.app"  # Cloud Run

def get_ga4_report():
    """Buscar relatório GA4 e enviar para BigQuery"""
    
    response = requests.post(
        f"{API_URL}/api/v1/report",
        json={
            "property_id": "123456789",  # Substituir!
            "start_date": "2024-01-01",
            "end_date": "2024-01-31",
            "dimensions": ["date", "eventName"],
            "metrics": ["activeUsers", "eventCount"],
            "limit": 1000
        }
    )
    
    result = response.json()
    print(json.dumps(result, indent=2))
    
    return result

# get_ga4_report()

# ============================================================================
# EXEMPLO 4: Python - Com Filtros
# ============================================================================

def get_ga4_report_filtered():
    """Buscar relatório com filtros"""
    
    response = requests.post(
        f"{API_URL}/api/v1/report",
        json={
            "property_id": "123456789",
            "start_date": "2024-01-01",
            "end_date": "2024-01-31",
            "dimensions": ["date", "country", "deviceCategory"],
            "metrics": ["sessions", "bounceRate", "avgSessionDuration"],
            "filters": [
                {
                    "field_name": "eventName",
                    "string_filter": {
                        "match_type": "EXACT",
                        "value": "page_view"
                    }
                },
                {
                    "field_name": "country",
                    "in_list_filter": {
                        "values": ["Brazil", "United States"],
                        "case_sensitive": False
                    }
                }
            ],
            "limit": 5000
        }
    )
    
    result = response.json()
    print(json.dumps(result, indent=2))
    
    return result

# get_ga4_report_filtered()

# ============================================================================
# EXEMPLO 5: Python - Obter Metadados
# ============================================================================

def get_ga4_metadata():
    """Listar todas as dimensions e metrics disponíveis"""
    
    response = requests.post(
        f"{API_URL}/api/v1/metadata",
        json={"property_id": "123456789"}
    )
    
    metadata = response.json()
    
    # Imprimir disponíveis
    if "metadata" in metadata:
        print("Dimensions disponíveis:")
        for dim in metadata["metadata"].get("dimensions", [])[:10]:
            print(f"  - {dim}")
        
        print("\nMetrics disponíveis:")
        for metric in metadata["metadata"].get("metrics", [])[:10]:
            print(f"  - {metric}")
    
    return metadata

# get_ga4_metadata()

# ============================================================================
# EXEMPLO 6: Python - Consultar BigQuery
# ============================================================================

def query_bigquery():
    """Executar query direto no BigQuery"""
    
    response = requests.post(
        f"{API_URL}/api/v1/bigquery/query",
        json={
            "query": """
                SELECT 
                    COUNT(*) as total_rows,
                    COUNT(DISTINCT date) as unique_dates,
                    MIN(loaded_at) as first_load,
                    MAX(loaded_at) as last_load
                FROM `seu-projeto.ga4_data.analytics_report`
            """
        }
    )
    
    result = response.json()
    
    if "data" in result:
        for row in result["data"]:
            print(f"Total de linhas: {row.get('total_rows')}")
            print(f"Datas únicas: {row.get('unique_dates')}")
            print(f"Primeira carga: {row.get('first_load')}")
            print(f"Última carga: {row.get('last_load')}")
    
    return result

# query_bigquery()

# ============================================================================
# EXEMPLO 7: Python - Obter Schema BigQuery
# ============================================================================

def get_bigquery_schema():
    """Ver a estrutura da tabela no BigQuery"""
    
    response = requests.get(f"{API_URL}/api/v1/bigquery/schema")
    
    result = response.json()
    
    print(f"Tabela: {result['table']}")
    print("\nSchema:")
    for field in result["schema"]:
        print(f"  - {field['name']}: {field['type']} ({field['mode']})")
    
    return result

# get_bigquery_schema()

# ============================================================================
# EXEMPLO 8: Python - Automação Diária com Agendamento
# ============================================================================

from datetime import datetime, timedelta
import schedule
import time

def scheduled_ga4_sync():
    """Sincronizar GA4 com BigQuery todos os dias"""
    
    # Ontem
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    print(f"[{datetime.now()}] Sincronizando GA4 para {yesterday}...")
    
    response = requests.post(
        f"{API_URL}/api/v1/report",
        json={
            "property_id": "123456789",
            "start_date": yesterday,
            "end_date": yesterday,
            "dimensions": ["date", "eventName"],
            "metrics": ["activeUsers", "eventCount"],
            "limit": 10000
        }
    )
    
    result = response.json()
    
    if result["status"] == "success":
        print(f"✅ Sucesso! {result['rows_processed']} linhas sincronizadas")
    else:
        print(f"❌ Erro: {result.get('error')}")

def start_scheduler():
    """Iniciar scheduler para sync diário"""
    
    # Rodar todo dia às 2 da manhã
    schedule.every().day.at("02:00").do(scheduled_ga4_sync)
    
    print("Scheduler iniciado. Rodando em background...")
    
    while True:
        schedule.run_pending()
        time.sleep(60)

# schedule.every().hour.do(scheduled_ga4_sync)  # A cada hora
# start_scheduler()

# ============================================================================
# EXEMPLO 9: Python - Com Tratamento de Erros
# ============================================================================

def robust_ga4_request():
    """Requisição com tratamento robusto de erros"""
    
    try:
        response = requests.post(
            f"{API_URL}/api/v1/report",
            json={
                "property_id": "123456789",
                "start_date": "2024-01-01",
                "end_date": "2024-01-31",
                "dimensions": ["date"],
                "metrics": ["activeUsers"]
            },
            timeout=30  # Timeout de 30s
        )
        
        # Verificar status HTTP
        response.raise_for_status()
        
        result = response.json()
        
        # Verificar resposta
        if result.get("status") == "success":
            print(f"✅ Sucesso: {result['rows_processed']} linhas")
            return result
        else:
            print(f"❌ Erro da API: {result.get('error')}")
            return None
    
    except requests.exceptions.Timeout:
        print("❌ Timeout: A requisição demorou muito")
    except requests.exceptions.ConnectionError:
        print("❌ Conexão recusada: Verificar se a API está rodando")
    except requests.exceptions.HTTPError as e:
        print(f"❌ Erro HTTP: {e.response.status_code}")
    except Exception as e:
        print(f"❌ Erro inesperado: {str(e)}")
    
    return None

# robust_ga4_request()

# ============================================================================
# EXEMPLO 10: Python - Processar Dados da Resposta
# ============================================================================

import pandas as pd

def process_ga4_data():
    """Buscar dados e processar localmente"""
    
    response = requests.post(
        f"{API_URL}/api/v1/report",
        json={
            "property_id": "123456789",
            "start_date": "2024-01-01",
            "end_date": "2024-01-31",
            "dimensions": ["date", "eventName"],
            "metrics": ["activeUsers", "eventCount"]
        }
    )
    
    result = response.json()
    
    if result["status"] == "success":
        print(f"Dados carregados em BigQuery!")
        print(f"Tabela: {result['bigquery_table']}")
        print(f"Linhas: {result['rows_processed']}")
        
        # Agora consultar os dados para processar localmente
        query_response = requests.post(
            f"{API_URL}/api/v1/bigquery/query",
            json={
                "query": f"""
                    SELECT 
                        date,
                        eventName,
                        CAST(activeUsers AS INT64) as activeUsers,
                        CAST(eventCount AS INT64) as eventCount
                    FROM `seu-projeto.ga4_data.analytics_report`
                    WHERE DATE(loaded_at) = CURRENT_DATE()
                    LIMIT 1000
                """
            }
        )
        
        query_result = query_response.json()
        
        if "data" in query_result:
            # Converter para DataFrame
            df = pd.DataFrame(query_result["data"])
            
            # Processar
            summary = df.groupby("eventName").agg({
                "activeUsers": "sum",
                "eventCount": "sum"
            })
            
            print("\nResumo por evento:")
            print(summary)
            
            return df
    
    return None

# df = process_ga4_data()

# ============================================================================
# EXEMPLO 11: Python - Sincronização Multiplas Properties
# ============================================================================

def sync_multiple_properties(property_ids):
    """Sincronizar múltiplas GA4 properties"""
    
    results = []
    
    for prop_id in property_ids:
        print(f"\nSincronizando property {prop_id}...")
        
        try:
            response = requests.post(
                f"{API_URL}/api/v1/report",
                json={
                    "property_id": prop_id,
                    "start_date": "2024-01-01",
                    "end_date": "2024-01-31",
                    "dimensions": ["date", "eventName"],
                    "metrics": ["activeUsers"],
                    "limit": 1000
                }
            )
            
            result = response.json()
            
            if result["status"] == "success":
                print(f"✅ {prop_id}: {result['rows_processed']} linhas")
                results.append({"property_id": prop_id, "status": "success"})
            else:
                print(f"❌ {prop_id}: {result.get('error')}")
                results.append({"property_id": prop_id, "status": "error"})
        
        except Exception as e:
            print(f"❌ {prop_id}: {str(e)}")
            results.append({"property_id": prop_id, "status": "error"})
    
    return results

# properties = ["123456789", "987654321", "555666777"]
# results = sync_multiple_properties(properties)

# ============================================================================
# EXEMPLO 12: Python - Configurar como Módulo Reutilizável
# ============================================================================

class GA4BigQueryClient:
    """Cliente para fazer requisições à API GA4"""
    
    def __init__(self, base_url="http://localhost:8080"):
        self.base_url = base_url
        self.session = requests.Session()
    
    def health_check(self):
        """Verificar se a API está disponível"""
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def get_report(self, property_id, start_date, end_date, 
                   dimensions, metrics, filters=None, limit=10000):
        """Buscar relatório GA4"""
        
        payload = {
            "property_id": property_id,
            "start_date": start_date,
            "end_date": end_date,
            "dimensions": dimensions,
            "metrics": metrics,
            "limit": limit
        }
        
        if filters:
            payload["filters"] = filters
        
        response = self.session.post(
            f"{self.base_url}/api/v1/report",
            json=payload
        )
        
        return response.json()
    
    def get_metadata(self, property_id):
        """Obter metadados GA4"""
        response = self.session.post(
            f"{self.base_url}/api/v1/metadata",
            json={"property_id": property_id}
        )
        return response.json()
    
    def query(self, sql):
        """Executar query BigQuery"""
        response = self.session.post(
            f"{self.base_url}/api/v1/bigquery/query",
            json={"query": sql}
        )
        return response.json()
    
    def get_schema(self):
        """Obter schema BigQuery"""
        response = self.session.get(f"{self.base_url}/api/v1/bigquery/schema")
        return response.json()

# Uso:
# client = GA4BigQueryClient()
# if client.health_check():
#     data = client.get_report("123456789", "2024-01-01", "2024-01-31", 
#                              ["date"], ["activeUsers"])
#     print(data)

# ============================================================================
# COMO EXECUTAR ESTES EXEMPLOS
# ============================================================================

"""
1. Instalar dependências:
   pip install requests pandas schedule

2. Descomente o exemplo que quer rodar

3. Adapte os valores (property_id, datas, etc.)

4. Execute:
   python examples.py

5. Para testar localmente:
   # Terminal 1
   python main.py
   
   # Terminal 2
   python examples.py
"""

# ============================================================================
# DICAS
# ============================================================================

"""
💡 DICAS ÚTEIS:

1. Sempre verificar resposta com response.json()
2. Usar try/except para requisições
3. Respeitar limites de rate (ajustar limit)
4. Usar agendamento para sincronizações periódicas
5. Monitorar logs em produção
6. Testar com Postman primeiro
7. Usar variáveis de ambiente para URLs
8. Implementar retry logic para resiliência
9. Processar dados em chunks se for grande volume
10. Documentar suas integrações
"""

if __name__ == "__main__":
    print("GA4 to BigQuery API - Exemplos Práticos")
    print("=" * 50)
    print("\nDescomente os exemplos que quer executar")
    print("e execute este script.")
    print("\nExemplos disponíveis:")
    print("  1. get_ga4_report()")
    print("  2. get_ga4_report_filtered()")
    print("  3. get_ga4_metadata()")
    print("  4. query_bigquery()")
    print("  5. get_bigquery_schema()")
    print("  6. scheduled_ga4_sync()")
    print("  7. robust_ga4_request()")
    print("  8. process_ga4_data()")
    print("  9. sync_multiple_properties()")
    print(" 10. GA4BigQueryClient")
