# Quick Start - GA4 to BigQuery API

Guia rápido para começar a usar a API em 10 minutos.

## ⚡ Setup Inicial (5 minutos)

### 1. Preparar Ambiente

```bash
# Entrar na pasta
cd GoogleAnalytics4

# Criar virtual environment
python -m venv venv

# Ativar (Windows)
venv\Scripts\activate

# Ativar (macOS/Linux)
source venv/bin/activate
```

### 2. Instalar Dependências

```bash
pip install -r requirements.txt
```

### 3. Configurar Variáveis de Ambiente

```bash
# Copiar template
cp .env.example .env

# Editar .env com seus valores:
# - GCP_PROJECT_ID
# - GOOGLE_CREDENTIALS (JSON da Service Account)
```

### 4. Executar a API

```bash
python main.py
```

A API estará disponível em: **http://localhost:8080**

---

## 🧪 Testar (5 minutos)

### Health Check
```bash
curl http://localhost:8080/health
```

Resposta esperada:
```json
{"status": "healthy"}
```

### Buscar Relatório GA4

```bash
curl -X POST http://localhost:8080/api/v1/report \
  -H "Content-Type: application/json" \
  -d '{
    "property_id": "123456789",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "dimensions": ["date", "eventName"],
    "metrics": ["activeUsers", "eventCount"]
  }'
```

Resposta esperada:
```json
{
  "status": "success",
  "rows_processed": 1250,
  "property_id": "123456789",
  "start_date": "2024-01-01",
  "end_date": "2024-01-31",
  "bigquery_table": "seu-projeto.ga4_data.analytics_report"
}
```

---

## 📋 Endpoints Disponíveis

### 1. Health Check
```
GET /health
```

### 2. Buscar Relatório GA4
```
POST /api/v1/report
```

Body obrigatório:
```json
{
  "property_id": "123456789",
  "start_date": "2024-01-01",
  "end_date": "2024-01-31",
  "dimensions": ["date", "eventName"],
  "metrics": ["activeUsers"]
}
```

### 3. Metadados GA4
```
POST /api/v1/metadata
```

Body:
```json
{
  "property_id": "123456789"
}
```

### 4. Schema BigQuery
```
GET /api/v1/bigquery/schema
```

### 5. Query BigQuery
```
POST /api/v1/bigquery/query
```

Body:
```json
{
  "query": "SELECT * FROM `seu-projeto.ga4_data.analytics_report` LIMIT 10"
}
```

---

## 🔑 Preparar Credenciais

### Obter Service Account

1. Ir para: https://console.cloud.google.com/iam-admin/serviceaccounts
2. Criar uma nova Service Account (nome: `ga4-api`)
3. Gerar chave JSON
4. Baixar arquivo `key.json`

### Configurar no .env

```bash
# Converter credenciais para string
cat key.json | jq -c . | tr -d '\n'

# Copiar o resultado e colar em .env:
GOOGLE_CREDENTIALS={resultado_acima}
```

---

## ✅ Pré-requisitos

- Python 3.9+
- Conta Google Cloud Platform
- Service Account com credenciais JSON
- BigQuery API habilitada
- Google Analytics Data API habilitada

---

## 🐛 Troubleshooting

### "Connection refused"
```bash
# Verificar se a API está rodando
curl http://localhost:8080/health
```

### "Module not found"
```bash
# Reinstalar dependências
pip install -r requirements.txt
```

### "Authentication error"
```bash
# Verificar se GOOGLE_CREDENTIALS está correto em .env
# Deve ser um JSON válido em uma única linha
cat .env | grep GOOGLE_CREDENTIALS
```

### "BigQuery dataset not found"
```bash
# Criar o dataset (execute uma vez)
bq mk --dataset ga4_data
```

---

## 📚 Próximos Passos

1. **Entender a API:** Leia [API_DEPLOYMENT.md](API_DEPLOYMENT.md)
2. **Arquitetura:** Leia [ARCHITECTURE.md](ARCHITECTURE.md)
3. **Mais detalhes:** Leia [INSTALL.md](INSTALL.md)

---

**Tempo total:** ~10 minutos do setup ao teste ✅
