# Google Analytics 4 to BigQuery API

Transformação do módulo GoogleAnalytics4 em uma API REST para executar no Google Cloud Run, com integração direta ao Google BigQuery.

## Arquitetura

```
Google Analytics 4
        ↓
   Cloud Run API
        ↓
   Google BigQuery
```

## Pré-requisitos

1. Projeto no Google Cloud Platform
2. APIs habilitadas:
   - Cloud Run API
   - BigQuery API
   - Google Analytics Admin API
   - Google Analytics Data API
   - Secret Manager API (opcional)

3. Service Account com permissões:
   - BigQuery Admin
   - Editor na Google Analytics 4

## Variáveis de Ambiente

Defina as seguintes variáveis antes de implantar:

| Variável | Descrição | Exemplo |
|----------|-----------|---------|
| `GCP_PROJECT_ID` | ID do projeto GCP | `my-project-123` |
| `BIGQUERY_DATASET_ID` | ID do dataset BigQuery | `ga4_data` |
| `BIGQUERY_TABLE_ID` | ID da tabela BigQuery | `analytics_report` |
| `GOOGLE_CREDENTIALS` | JSON com credenciais da Service Account | JSON string |
| `PORT` | Porta da aplicação | `8080` (padrão) |

## Endpoints da API

### 1. Health Check
```
GET /health
```
Verifica se a API está funcionando.

**Resposta:**
```json
{
  "status": "healthy"
}
```

### 2. Obter Relatório GA4 e Enviar para BigQuery
```
POST /api/v1/report
Content-Type: application/json
```

**Body:**
```json
{
  "property_id": "123456789",
  "start_date": "2024-01-01",
  "end_date": "2024-01-31",
  "dimensions": ["date", "eventName"],
  "metrics": ["activeUsers", "eventCount"],
  "filters": [
    {
      "field_name": "eventName",
      "string_filter": {
        "match_type": "EXACT",
        "value": "page_view"
      }
    }
  ],
  "limit": 10000
}
```

**Resposta (sucesso):**
```json
{
  "status": "success",
  "rows_processed": 1250,
  "property_id": "123456789",
  "start_date": "2024-01-01",
  "end_date": "2024-01-31",
  "bigquery_table": "my-project-123.ga4_data.analytics_report"
}
```

### 3. Obter Metadados GA4
```
POST /api/v1/metadata
Content-Type: application/json
```

**Body:**
```json
{
  "property_id": "123456789"
}
```

**Resposta:**
```json
{
  "status": "success",
  "property_id": "123456789",
  "metadata": {
    "dimensions": [...],
    "metrics": [...]
  }
}
```

### 4. Obter Schema da Tabela BigQuery
```
GET /api/v1/bigquery/schema
```

**Resposta:**
```json
{
  "status": "success",
  "table": "my-project-123.ga4_data.analytics_report",
  "schema": [
    {
      "name": "date",
      "type": "STRING",
      "mode": "NULLABLE"
    },
    {
      "name": "activeUsers",
      "type": "INTEGER",
      "mode": "NULLABLE"
    }
  ]
}
```

### 5. Executar Query no BigQuery
```
POST /api/v1/bigquery/query
Content-Type: application/json
```

**Body:**
```json
{
  "query": "SELECT * FROM `my-project-123.ga4_data.analytics_report` LIMIT 100"
}
```

**Resposta:**
```json
{
  "status": "success",
  "rows_returned": 100,
  "data": [...]
}
```

## Implantação no Cloud Run

### 1. Criar Dataset no BigQuery (uma única vez)
```bash
   pip install flask

### 2. Preparar Service Account
```bash
# Criar service account
gcloud iam service-accounts create ga4-api \
  --display-name="GA4 API Service Account" \
  --project="cadastra-yducs-prod"

# Atribuir permissões BigQuery
gcloud projects add-iam-policy-binding "cadastra-yducs-prod" \
  --member=serviceAccount:yducs-cloud-composer-pipelines@cadastra-yducs-prod.iam.gserviceaccount.com \
  --role=roles/bigquery.admin

# Atribuir permissões Google Analytics
gcloud projects add-iam-policy-binding "cadastra-yducs-prod" \
  --member=serviceAccount:yducs-cloud-composer-pipelines@cadastra-yducs-prod.iam.gserviceaccount.com \
  --role=roles/analytics.viewer

# Criar chave JSON
gcloud iam service-accounts keys create key.json \
  --iam-account=yducs-cloud-composer-pipelines@cadastra-yducs-prod.iam.gserviceaccount.com \
  --project="cadastra-yducs-prod"
```

### 3. Build e Deploy no Cloud Run
```bash
# Autenticar
gcloud auth login

# Definir projeto
gcloud config set project YOUR_PROJECT_ID

# Build da imagem
gcloud builds submit \
  --tag gcr.io/cadastra-yducs-prod/ga4-api:latest \
  --project="cadastra-yducs-prod"

# Deploy no Cloud Run
gcloud run deploy ga4-api \
  --image gcr.io/cadastra-yducs-prod/ga4-api:latest \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars="GCP_PROJECT_ID=cadastra-yducs-prod,BIGQUERY_DATASET_ID=ga4_data,BIGQUERY_TABLE_ID=raw,GOOGLE_CREDENTIALS=$(cat application_default_credentials.json | jq -c .)" \
  --project="cadastra-yducs-prod"
```

### 4. Alternativa: Usando Cloud Deploy com Terraform
Ver arquivo `deploy.tf` para configuração com Terraform.

## Exemplo de Uso

### Python
```python
import requests
import json

BASE_URL = "https://YOUR_CLOUD_RUN_URL"

# 1. Buscar relatório GA4 e enviar para BigQuery
response = requests.post(
    f"{BASE_URL}/api/v1/report",
    json={
        "property_id": "123456789",
        "start_date": "2024-01-01",
        "end_date": "2024-01-31",
        "dimensions": ["date", "eventName"],
        "metrics": ["activeUsers", "eventCount"]
    }
)
print(response.json())

# 2. Consultar dados no BigQuery
response = requests.post(
    f"{BASE_URL}/api/v1/bigquery/query",
    json={
        "query": "SELECT * FROM `YOUR_PROJECT_ID.ga4_data.analytics_report` LIMIT 10"
    }
)
data = response.json()
for row in data['data']:
    print(row)
```

### cURL
```bash
# Health check
curl https://YOUR_CLOUD_RUN_URL/health

# Buscar relatório
curl -X POST https://YOUR_CLOUD_RUN_URL/api/v1/report \
  -H "Content-Type: application/json" \
  -d '{
    "property_id": "123456789",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "dimensions": ["date", "eventName"],
    "metrics": ["activeUsers"]
  }'
```

## Monitoramento

### Logs
```bash
gcloud run logs read ga4-api \
  --region us-central1 \
  --project YOUR_PROJECT_ID \
  --limit 50
```

### Métricas
```bash
gcloud monitoring dashboards create \
  --config-from-file=monitoring-dashboard.yaml
```

## Troubleshooting

### Erro de Autenticação
Certifique-se de que:
1. A variável `GOOGLE_CREDENTIALS` contém um JSON válido
2. A Service Account tem as permissões corretas
3. A credencial não expirou

### Erro ao Inserir no BigQuery
1. Verifique se o dataset existe
2. Confirme que a tabela tem a estrutura correta
3. Verifique os logs: `gcloud run logs read ga4-api`

### Erro de Timeout
1. Aumentar o timeout no Cloud Run (máximo 3600s)
2. Ajustar o `limit` na request para dados menores
3. Considerar processar dados em chunks

## Customização

### Adicionar Filtros Customizados
Modifique o método `__build_filter_expression()` em `GoogleAnalytics4.py`.

### Customizar Schema BigQuery
Defina um schema customizado na função `insert_to_bigquery()`:
```python
job_config = bigquery.LoadJobConfig(
    schema=[
        bigquery.SchemaField("date", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("activeUsers", "INTEGER", mode="NULLABLE"),
    ],
    write_disposition="WRITE_APPEND",
)
```

## Segurança

1. **Não exponha credenciais**: Use variáveis de ambiente ou Secret Manager
2. **Autenticação**: Considere adicionar autenticação Cloud Run com Identity Platform
3. **Rate Limiting**: Implementar rate limiting para proteger a API
4. **Audit Logging**: Habilitar Cloud Audit Logs para todas as operações

## Custos

Tenha em mente:
- Cloud Run: $0.40 por milhão de requisições
- BigQuery: $0.025 por GB de dados lidos
- Cloud Build: $0.003 por minuto de build

## Suporte

Para problemas:
1. Verificar logs: `gcloud run logs read ga4-api`
2. Testar endpoints com cURL
3. Validar permissões IAM
4. Consultar documentação oficial do Google Cloud
