"""
Exemplos de teste para a API GA4 to BigQuery
"""
import requests
import json
from datetime import datetime, timedelta

# Substituir pela URL real
BASE_URL = "http://localhost:8080"  # Local
# BASE_URL = "https://ga4-api-xxxxx.run.app"  # Cloud Run


def test_health():
    """Testar endpoint de health check"""
    print("\n=== Teste: Health Check ===")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    assert response.status_code == 200


def test_get_report():
    """Testar obtenção de relatório GA4 e envio para BigQuery"""
    print("\n=== Teste: Obter Relatório GA4 ===")
    
    # Definir período de 7 dias atrás
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=7)
    
    payload = {
        "property_id": "123456789",  # Substituir por Property ID real
        "start_date": str(start_date),
        "end_date": str(end_date),
        "dimensions": ["date", "eventName"],
        "metrics": ["activeUsers", "eventCount"],
        "limit": 1000
    }
    
    print(f"Request payload: {json.dumps(payload, indent=2)}")
    
    response = requests.post(
        f"{BASE_URL}/api/v1/report",
        json=payload
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200
    assert response.json()["status"] == "success"


def test_get_report_with_filters():
    """Testar relatório com filtros"""
    print("\n=== Teste: Relatório com Filtros ===")
    
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=30)
    
    payload = {
        "property_id": "123456789",
        "start_date": str(start_date),
        "end_date": str(end_date),
        "dimensions": ["date", "country"],
        "metrics": ["sessions", "bounceRate"],
        "filters": [
            {
                "field_name": "eventName",
                "string_filter": {
                    "match_type": "EXACT",
                    "value": "page_view"
                }
            }
        ],
        "limit": 5000
    }
    
    print(f"Request payload: {json.dumps(payload, indent=2)}")
    
    response = requests.post(
        f"{BASE_URL}/api/v1/report",
        json=payload
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200


def test_get_metadata():
    """Testar obtenção de metadados GA4"""
    print("\n=== Teste: Obter Metadados ===")
    
    payload = {
        "property_id": "123456789"
    }
    
    response = requests.post(
        f"{BASE_URL}/api/v1/metadata",
        json=payload
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)[:500]}...")  # Primeiros 500 chars
    
    assert response.status_code == 200


def test_bigquery_schema():
    """Testar obtenção do schema BigQuery"""
    print("\n=== Teste: BigQuery Schema ===")
    
    response = requests.get(f"{BASE_URL}/api/v1/bigquery/schema")
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200


def test_bigquery_query():
    """Testar query no BigQuery"""
    print("\n=== Teste: BigQuery Query ===")
    
    payload = {
        "query": """
            SELECT 
                COUNT(*) as total_rows,
                MIN(loaded_at) as first_load,
                MAX(loaded_at) as last_load
            FROM `{PROJECT_ID}.ga4_data.analytics_report`
            LIMIT 10
        """.format(PROJECT_ID="seu-projeto-id")  # Substituir PROJECT_ID
    }
    
    response = requests.post(
        f"{BASE_URL}/api/v1/bigquery/query",
        json=payload
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200


def test_missing_required_fields():
    """Testar erro com campos obrigatórios faltando"""
    print("\n=== Teste: Campos Obrigatórios Faltando ===")
    
    payload = {
        "property_id": "123456789",
        # Faltam: start_date, end_date, dimensions, metrics
    }
    
    response = requests.post(
        f"{BASE_URL}/api/v1/report",
        json=payload
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 400
    assert "error" in response.json()


def test_invalid_endpoint():
    """Testar endpoint inválido"""
    print("\n=== Teste: Endpoint Inválido ===")
    
    response = requests.get(f"{BASE_URL}/api/invalid/endpoint")
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 404


def run_all_tests():
    """Executar todos os testes"""
    print("=" * 60)
    print("Iniciando testes da API GA4 to BigQuery")
    print("=" * 60)
    
    tests = [
        test_health,
        test_missing_required_fields,
        test_invalid_endpoint,
        test_bigquery_schema,
        # Uncomment para testar com dados reais
        # test_get_report,
        # test_get_report_with_filters,
        # test_get_metadata,
        # test_bigquery_query,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            print(f"✓ {test.__name__} - PASSOU")
            passed += 1
        except AssertionError as e:
            print(f"✗ {test.__name__} - FALHOU: {str(e)}")
            failed += 1
        except Exception as e:
            print(f"✗ {test.__name__} - ERRO: {str(e)}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"Resultados: {passed} passou(s), {failed} falhou(s)")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()
