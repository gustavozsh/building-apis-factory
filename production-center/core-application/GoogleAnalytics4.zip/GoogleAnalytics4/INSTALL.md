# 🚀 GA4 to BigQuery API - Guia de Instalação e Deploy

## ⚡ 60 Segundos de Setup

### Opção 1: Deploy Automático (Recomendado)
```bash
cd GoogleAnalytics4

# 1. Obter arquivo de credenciais (key.json)
# Ir para: https://console.cloud.google.com/iam-admin/serviceaccounts

# 2. Executar deploy
chmod +x deploy.sh
./deploy.sh seu-projeto-id us-central1

# Pronto! A API está em produção no Cloud Run
```

### Opção 2: Local com Docker
```bash
cd GoogleAnalytics4

# Copiar e editar .env
cp .env.example .env
# Editar .env e adicionar GCP_PROJECT_ID e GOOGLE_CREDENTIALS

# Iniciar
docker-compose up

# API em: http://localhost:8080
```

### Opção 3: Local com Python
```bash
cd GoogleAnalytics4

# Virtual environment
python -m venv venv
source venv/bin/activate  # macOS/Linux
# ou
venv\Scripts\activate  # Windows

# Instalar
pip install -r requirements.txt

# Configurar .env
cp .env.example .env
# Editar .env

# Executar
python main.py
```

---

## 🧪 Testar

### Health Check
```bash
curl http://localhost:8080/health
# Resposta: {"status": "healthy"}
```

### Buscar Relatório GA4
```bash
curl -X POST http://localhost:8080/api/v1/report \
  -H "Content-Type: application/json" \
  -d '{
    "property_id": "123456789",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "dimensions": ["date", "eventName"],
    "metrics": ["activeUsers", "eventCount"]
  }'
```

### Com Python
```python
import requests

response = requests.post(
    "http://localhost:8080/api/v1/report",
    json={
        "property_id": "123456789",
        "start_date": "2024-01-01",
        "end_date": "2024-01-31",
        "dimensions": ["date", "eventName"],
        "metrics": ["activeUsers"]
    }
)
print(response.json())
```

---

## 📋 Checklist Pré-Deploy

- [ ] Service Account criada no GCP
- [ ] Arquivo `key.json` baixado
- [ ] BigQuery API habilitada
- [ ] Google Analytics Data API habilitada
- [ ] Service Account tem permissão "BigQuery Admin"
- [ ] Arquivo `.env` preenchido com credenciais
- [ ] Testado localmente (`python test_api.py`)

---

## 🌐 Cloud Run Deploy via CLI

```bash
# 1. Autenticar
gcloud auth login
gcloud config set project seu-projeto-id

# 2. Build
gcloud builds submit \
  --tag gcr.io/seu-projeto-id/ga4-api:latest

# 3. Deploy
gcloud run deploy ga4-api \
  --image gcr.io/seu-projeto-id/ga4-api:latest \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 512Mi \
  --set-env-vars="GCP_PROJECT_ID=seu-projeto-id,BIGQUERY_DATASET_ID=ga4_data,BIGQUERY_TABLE_ID=analytics_report,GOOGLE_CREDENTIALS=$(cat key.json | jq -c .)"

# URL será exibida ao final
```

---

## 🗂️ Estrutura de Dados

### BigQuery Schema (Automático)
```
dataset: ga4_data
table: analytics_report
  - Colunas: Todas as dimensões e métricas do GA4
  - loaded_at: TIMESTAMP (quando foi carregado)
  - Particionado por: loaded_at (diário)
```

---

## 📊 5 Endpoints Principais

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/health` | Verificar se a API está viva |
| POST | `/api/v1/report` | Buscar GA4 → BigQuery |
| POST | `/api/v1/metadata` | Listar dimensions/metrics GA4 |
| GET | `/api/v1/bigquery/schema` | Ver schema da tabela |
| POST | `/api/v1/bigquery/query` | Executar query BigQuery |

---

## 🔑 Obter Credenciais

```bash
# 1. Ir para GCP Console
# https://console.cloud.google.com/iam-admin/serviceaccounts

# 2. Criar Service Account
# Nome: ga4-api

# 3. Gerar Chave JSON
# Actions → Manage keys → Add key → JSON

# 4. Usar no .env:
GOOGLE_CREDENTIALS=$(cat key.json | jq -c .)

# Ou no Cloud Run:
gcloud run deploy ga4-api \
  --set-env-vars="GOOGLE_CREDENTIALS=$(cat key.json | jq -c .)" ...
```

---

## 🐛 Troubleshooting

### Erro: "Invalid credentials"
```bash
# Verificar arquivo key.json
cat key.json | jq .

# Converter corretamente
CREDS=$(cat key.json | jq -c . | tr -d '\n')
echo $CREDS
```

### Erro: "BigQuery not found"
```bash
# Criar dataset
bq mk --dataset ga4_data

# Verificar
bq ls
bq show ga4_data
```

### Erro: "Timeout"
```bash
# Reduzir período de dados
# "start_date": "2024-01-25",  # ao invés de "2024-01-01"
# "end_date": "2024-01-31",

# Ou usar limit menor
# "limit": 1000  # ao invés de 10000
```

---

## 📚 Documentação Completa

- **QUICKSTART.md** - Guia rápido com exemplos
- **API_DEPLOYMENT.md** - Todos os endpoints + deployment
- **ARCHITECTURE.md** - Visão geral da arquitetura
- **test_api.py** - Exemplos de testes
- **postman_collection.json** - Para testar no Postman

---

## 🚨 Importante

### Segurança
⚠️ **NUNCA** commitar `key.json` ou credenciais no Git!
- Use `.gitignore` para excluir `key.json`
- Use variáveis de ambiente ou Secrets Manager
- No Cloud Run, usar Secrets Manager ou IAM

### Permissões Necessárias
```bash
# BigQuery Admin
# Google Analytics Viewer
# Secret Manager Secret Accessor (opcional)
```

---

## 💡 Próximos Passos

1. **Testar Localmente**
   ```bash
   python main.py
   python test_api.py
   ```

2. **Deploy no Cloud Run**
   ```bash
   ./deploy.sh seu-projeto us-central1
   ```

3. **Integrar com sua Aplicação**
   ```python
   # Chamar API da sua app
   requests.post(f"{API_URL}/api/v1/report", json=params)
   ```

4. **Monitorar**
   ```bash
   gcloud run logs read ga4-api
   ```

5. **Customizar** (Ver ARCHITECTURE.md para mais detalhes)

---

## 📞 Links Úteis

- [Google Cloud Console](https://console.cloud.google.com)
- [BigQuery Docs](https://cloud.google.com/bigquery/docs)
- [Cloud Run Docs](https://cloud.google.com/run/docs)
- [GA4 API](https://developers.google.com/analytics/devguides/reporting/data/v1)

---

## ✅ Status

- ✅ API pronta para produção
- ✅ Docker containerizado
- ✅ Cloud Run compatible
- ✅ BigQuery integration
- ✅ Fully documented

**Última atualização:** Janeiro 2024
**Versão:** 1.0
