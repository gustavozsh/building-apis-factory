"""
Google Analytics 4 to BigQuery API for Cloud Run
"""
import json
import os
from datetime import datetime
from typing import Optional
from flask import Flask, request, jsonify
from google.oauth2.service_account import Credentials
from google.cloud import bigquery
from loguru import logger

from GoogleAnalytics4 import GoogleAnalytics4

app = Flask(__name__)

# Initialize clients
PROJECT_ID = os.getenv("GCP_PROJECT_ID")
DATASET_ID = os.getenv("BIGQUERY_DATASET_ID", "raw")
TABLE_ID = os.getenv("BIGQUERY_TABLE_ID", "tb_ga_4")
CREDENTIALS_JSON = os.getenv("GOOGLE_CREDENTIALS")

# Initialize BigQuery client
bq_client = bigquery.Client(project=PROJECT_ID)

# Setup logging
logger.remove()
logger.add(
    lambda msg: print(msg, end=""),
    format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
    level="INFO"
)


def get_ga4_credentials():
    """Get GA4 credentials from environment variable"""
    try:
        credentials_dict = json.loads(CREDENTIALS_JSON)
        return Credentials.from_service_account_info(credentials_dict)
    except Exception as e:
        logger.error(f"Error loading credentials: {str(e)}")
        raise


def insert_to_bigquery(dataframe, table_id):
    """Insert data into BigQuery"""
    try:
        dataset_ref = bq_client.dataset(DATASET_ID)
        table_ref = dataset_ref.table(TABLE_ID)
        
        # Add timestamp column
        dataframe['loaded_at'] = datetime.utcnow().isoformat()
        
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_APPEND",
            autodetect=True,
        )
        
        job = bq_client.load_table_from_dataframe(
            dataframe, table_ref, job_config=job_config
        )
        
        job.result()  # Wait for job to complete
        logger.info(f"Loaded {len(dataframe)} rows into BigQuery")
        return True
    except Exception as e:
        logger.error(f"Error inserting data to BigQuery: {str(e)}")
        raise


@app.route("/health", methods=["GET"])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy"}), 200


@app.route("/api/v1/report", methods=["POST"])
def get_report():
    """
    Fetch GA4 report and send to BigQuery
    
    Request body:
    {
        "property_id": "123456789",
        "start_date": "2024-01-01",
        "end_date": "2026-01-14",
        "dimensions": ["date", "eventName"],
        "metrics": ["activeUsers", "eventCount"],
        "filters": [optional],
        "limit": 10000
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ["property_id", "start_date", "end_date", "dimensions", "metrics"]
        if not all(field in data for field in required_fields):
            return jsonify({
                "error": f"Missing required fields: {', '.join(required_fields)}"
            }), 400
        
        # Extract parameters
        property_id = data.get("property_id")
        start_date = data.get("start_date")
        end_date = data.get("end_date")
        dimensions = data.get("dimensions")
        metrics = data.get("metrics")
        filters = data.get("filters")
        limit = data.get("limit", 10000)
        
        logger.info(f"Processing report request for property {property_id}")
        
        # Get GA4 credentials and client
        credentials = get_ga4_credentials()
        ga4 = GoogleAnalytics4(credentials)
        
        # Request report
        logger.info(f"Fetching data from GA4 for period {start_date} to {end_date}")
        df = ga4.request_report(
            property_id=property_id,
            start_date=start_date,
            end_date=end_date,
            dimensions=dimensions,
            metrics=metrics,
            filters=filters,
            limit=limit
        )
        
        if df.empty:
            return jsonify({
                "message": "No data found for the specified period",
                "rows_processed": 0
            }), 200
        
        # Insert to BigQuery
        logger.info(f"Inserting {len(df)} rows to BigQuery")
        insert_to_bigquery(df, TABLE_ID)
        
        return jsonify({
            "status": "success",
            "rows_processed": len(df),
            "property_id": property_id,
            "start_date": start_date,
            "end_date": end_date,
            "bigquery_table": f"{PROJECT_ID}.{DATASET_ID}.{TABLE_ID}"
        }), 200
        
    except Exception as e:
        logger.error(f"Error processing report: {str(e)}")
        return jsonify({
            "error": str(e)
        }), 500


@app.route("/api/v1/metadata", methods=["POST"])
def get_metadata():
    """
    Get GA4 metadata for available dimensions and metrics
    
    Request body:
    {
        "property_id": "123456789"
    }
    """
    try:
        data = request.get_json()
        
        if "property_id" not in data:
            return jsonify({"error": "property_id is required"}), 400
        
        property_id = data.get("property_id")
        logger.info(f"Fetching metadata for property {property_id}")
        
        # Get GA4 credentials and client
        credentials = get_ga4_credentials()
        ga4 = GoogleAnalytics4(credentials)
        
        # Get metadata
        metadata = ga4.get_metadata(property_id=property_id)
        
        return jsonify({
            "status": "success",
            "property_id": property_id,
            "metadata": metadata
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching metadata: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/v1/bigquery/schema", methods=["GET"])
def get_bigquery_schema():
    """Get the current BigQuery table schema"""
    try:
        dataset_ref = bq_client.dataset(DATASET_ID)
        table_ref = dataset_ref.table(TABLE_ID)
        table = bq_client.get_table(table_ref)
        
        schema = [
            {
                "name": field.name,
                "type": field.field_type,
                "mode": field.mode
            }
            for field in table.schema
        ]
        
        return jsonify({
            "status": "success",
            "table": f"{PROJECT_ID}.{DATASET_ID}.{TABLE_ID}",
            "schema": schema
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching schema: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/v1/bigquery/query", methods=["POST"])
def query_bigquery():
    """
    Execute a query against BigQuery
    
    Request body:
    {
        "query": "SELECT * FROM `project.dataset.table` LIMIT 10"
    }
    """
    try:
        data = request.get_json()
        
        if "query" not in data:
            return jsonify({"error": "query is required"}), 400
        
        sql_query = data.get("query")
        logger.info(f"Executing BigQuery query")
        
        query_job = bq_client.query(sql_query)
        results = query_job.result()
        
        # Convert to list of dicts
        rows = [dict(row) for row in results]
        
        return jsonify({
            "status": "success",
            "rows_returned": len(rows),
            "data": rows
        }), 200
        
    except Exception as e:
        logger.error(f"Error executing query: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=False)
